function toggleChat() {
    document.getElementById('chat-box').classList.toggle('hidden');
}
